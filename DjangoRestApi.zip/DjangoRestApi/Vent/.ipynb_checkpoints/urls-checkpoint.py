from django.urls import path

from Vent.views import vent_details_all_or_new,vent_specific_details_get_update,login,logout

app_name = 'vent'

urlpatterns = [
    path('',vent_details_all_or_new,name='details'),
    path('<pk>',vent_specific_details_get_update,name='details2'),
    path('login/', login,name="login"),
    path('logout', logout,name="logout"),
]