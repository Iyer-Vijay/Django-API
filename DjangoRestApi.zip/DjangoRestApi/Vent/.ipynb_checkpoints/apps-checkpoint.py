from django.apps import AppConfig


class VentConfig(AppConfig):
    name = 'Vent'
