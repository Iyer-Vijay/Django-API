from rest_framework import serializers
from Vent.models import Covid

class VentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Covid
        fields = ['facilityName','tier','region','group','lat','lng','totalVents','availableVents','predictedVentShortagein14days']