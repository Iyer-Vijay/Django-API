import json, pytest, requests

BASE_URL = "http://127.0.0.1:8000/Vent/vent/"
USERNAME = 'xyz123'
PASSWORD = 'qpwoeiruty123'


@pytest.fixture(scope="module", name="auth_vj")
def get_auth():
    class Auth:
        def __init__(self):
            self.token = None

    return Auth()


def test_login(auth_vj):
    url = BASE_URL + 'login'
    data = {
        'username': USERNAME,
        'password': PASSWORD
    }
    kwargs = {
        "data": data
    }
    response = requests.post(url=url, **kwargs)
    if response.status_code == 200:
        _dict = json.loads(response.text)
        if 'token' in _dict.keys():
            auth.token = _dict['token']
            if len(auth.token) > 0:
                assert True
                return

    assert False

def test_logout(auth_vj):
    test_login(auth)
    url = BASE_URL + 'logout'
    headers = {
        'Authorization': 'Token ' + auth.token
    }
    kwargs = {
        "headers": headers
    }
    response = requests.post(url=url, **kwargs)
    if response.status_code == 200:
        print("Logged Out")
        assert True
        return
    assert False

def test_vent_all_new(auth_vj):
    url = BASE_URL + ''
    headers = {
        'Authorization': 'Token ' + auth_paras.token
    }
    kwargs = {
        "headers": headers
    }
    response = requests.get(url=url, **kwargs)
    _dict = json.loads(response.text)
    if 'count' in _dict.keys():
        if _dict['count'] > 0:
            assert True
            return

    assert False
    
def test_vent_specific(auth_vj):
    url = BASE_URL + 'Acadia St. Landry Hospital/'
    headers = {
        'Authorization': 'Token ' + auth_paras.token
    }
    kwargs = {
        "headers": headers
    }
    response = requests.get(url=url, **kwargs)
    _dict = json.loads(response.text)
    if 'count' in _dict.keys():
        if _dict['count'] > 0:
            assert True
            return

    assert False