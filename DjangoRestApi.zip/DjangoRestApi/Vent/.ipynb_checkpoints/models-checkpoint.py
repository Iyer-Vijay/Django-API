from django.db import models

# Create your models here.
class Covid(models.Model):
    facilityName = models.CharField(primary_key=True,max_length = 100)
    tier = models.IntegerField()
    region = models.CharField(max_length = 100)
    group = models.CharField(max_length = 100)
    lat = models.FloatField()
    lng = models.FloatField()
    totalVents = models.IntegerField()
    availableVents = models.IntegerField()
    predictedVentShortagein14days = models.IntegerField()
    
    def __str__(self):
        return str(self.facilityName)